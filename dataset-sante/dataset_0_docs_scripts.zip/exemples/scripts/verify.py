"""Contrôles qualité du jeu de données final."""
import sys, os, csv, hashlib, collections
import numpy as np, scipy.io.wavfile as wf, scipy.signal as sg
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import confusion_matrix, classification_report

OUT = sys.argv[1]
meta = list(csv.DictReader(open(f"{OUT}/metadata.csv", encoding="utf-8")))
SR = 16000


def melbank(n_fft=512, n_mels=64):
    def hz2mel(f): return 2595 * np.log10(1 + f / 700)
    def mel2hz(m): return 700 * (10 ** (m / 2595) - 1)
    pts = mel2hz(np.linspace(hz2mel(30), hz2mel(8000), n_mels + 2))
    bins = np.floor((n_fft + 1) * pts / SR).astype(int)
    fb = np.zeros((n_mels, n_fft // 2 + 1))
    for i in range(n_mels):
        a, b, c = bins[i], bins[i + 1], bins[i + 2]
        fb[i, a:b] = (np.arange(a, b) - a) / max(b - a, 1)
        fb[i, b:c] = (c - np.arange(b, c)) / max(c - b, 1)
    return fb


FB = melbank()
problems = collections.Counter()
hashes = collections.defaultdict(list)
X, Xs, y, split = [], [], [], []
for m in meta:
    p = f"{OUT}/{m['fichier']}"
    sr, x = wf.read(p)
    ok = sr == 16000 and x.dtype == np.int16 and x.ndim == 1 and len(x) == 32000
    if not ok:
        problems["format"] += 1
    hashes[hashlib.md5(x.tobytes()).hexdigest()].append(p)
    xf = x.astype(np.float32) / 32768
    rms = np.sqrt((xf ** 2).mean())
    if 20 * np.log10(rms + 1e-9) < -50:
        problems["quasi_silence"] += 1
    if (np.abs(x) >= 32767).mean() > 0.001:
        problems["saturation"] += 1
    f, t, S = sg.stft(xf, SR, nperseg=512, noverlap=352)
    P = np.abs(S) ** 2
    M = np.log(FB @ P + 1e-10)
    feat = np.concatenate([M.mean(1), M.std(1), np.diff(M, axis=1).std(1), M.max(1)])
    hf = P[f > 3900].sum() / (P.sum() + 1e-12)
    crest = np.abs(xf).max() / (rms + 1e-9)
    X.append(feat); Xs.append([np.log10(hf + 1e-9), 20 * np.log10(rms + 1e-9), crest]); y.append(m["classe"])
    split.append(m["split_conseille"])

print("Problèmes :", dict(problems) or "aucun")
print("Doublons exacts :", sum(len(v) - 1 for v in hashes.values() if len(v) > 1))
X, Xs, y, split = np.array(X), np.array(Xs), np.array(y), np.array(split)
tr, te = split == "train", split == "test"
print("train/test :", tr.sum(), te.sum())
print(collections.Counter(zip(y[te])))
labels = sorted(set(y))
for name, F in (("Classifieur simple (log-mel)", X), ("Test anti-raccourci (seulement aigus>3,9kHz, volume, crête)", Xs)):
    clf = HistGradientBoostingClassifier(max_iter=300, random_state=0).fit(F[tr], y[tr])
    pr = clf.predict(F[te])
    print("\n==", name, "— exactitude test :", round((pr == y[te]).mean(), 3))
    print(classification_report(y[te], pr, digits=3, zero_division=0))
    if F is X:
        cm = confusion_matrix(y[te], pr, labels=labels)
        print("matrice de confusion (lignes = vrai) :", labels)
        for l, row in zip(labels, cm):
            print(f"{l:>11}", " ".join(f"{v:4d}" for v in row))
