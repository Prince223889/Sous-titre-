"""Outils audio communs : lecture via ffmpeg, segmentation, effets, synthèse."""
import subprocess, numpy as np, scipy.signal as sg, scipy.io.wavfile as wf

SR = 16000
DUR = 2.0
N = int(SR * DUR)


def load(path, sr=SR):
    """Décode n'importe quel fichier audio en float32 mono à `sr` Hz."""
    cmd = ["ffmpeg", "-v", "error", "-nostdin", "-i", str(path), "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    out = subprocess.run(cmd, capture_output=True, timeout=120)
    if out.returncode != 0:
        return None
    x = np.frombuffer(out.stdout, dtype=np.float32).copy()
    if x.size == 0 or not np.isfinite(x).all():
        return None
    return x - x.mean()


def save(path, x, sr=SR):
    x = np.clip(x, -1, 1)
    wf.write(str(path), sr, (x * 32767).astype(np.int16))


def frame_rms(x, hop=160, win=400):
    if len(x) < win:
        x = np.pad(x, (0, win - len(x)))
    nf = 1 + (len(x) - win) // hop
    idx = np.arange(win)[None, :] + hop * np.arange(nf)[:, None]
    return np.sqrt((x[idx] ** 2).mean(1) + 1e-12)


def db(v):
    return 20 * np.log10(v + 1e-12)


def fit(seg, rng, n=N):
    """Ramène un segment à n échantillons : centre-pad (aléatoire) ou crop."""
    if len(seg) >= n:
        return seg[:n]
    pad = n - len(seg)
    seg = seg.copy()
    f = min(int(0.015 * SR), len(seg) // 4)  # fondus de 15 ms : pas de coupure nette artificielle
    if f > 1:
        ramp = np.linspace(0, 1, f, dtype=seg.dtype)
        seg[:f] *= ramp
        seg[-f:] *= ramp[::-1]
    left = rng.integers(0, pad + 1)
    return np.pad(seg, (left, pad - left))


def event_windows(x, rng, max_win=8, min_rel_db=-25, hop_s=None, min_active=0.08):
    """Fenêtres de DUR secondes centrées sur les pics d'énergie.
    Garde uniquement les fenêtres réellement « actives » (évite les clips vides)."""
    if len(x) <= N:
        r = frame_rms(x)
        if db(r.max()) < -55:
            return []
        return [fit(x, rng)]
    r = frame_rms(x)
    rdb = db(r)
    peak = rdb.max()
    if peak < -55:
        return []
    sm = np.convolve(rdb, np.ones(5) / 5, "same")
    order = np.argsort(-sm)
    chosen = []
    half = N // 2
    min_dist = int(DUR * 100)  # en trames de 10 ms
    for fi in order:
        if sm[fi] < peak + min_rel_db:
            break
        if any(abs(fi - c) < min_dist for c in chosen):
            continue
        chosen.append(fi)
        if len(chosen) >= max_win:
            break
    out = []
    for fi in sorted(chosen):
        c = fi * 160 + 200 + int(rng.integers(-SR // 4, SR // 4))
        s = int(np.clip(c - half, 0, len(x) - N))
        seg = x[s:s + N]
        a = db(frame_rms(seg))
        if (a > peak + min_rel_db).mean() < min_active:
            continue
        out.append(seg)
    return out


def normalize(x, rng, lo=-12, hi=-1):
    p = np.abs(x).max()
    if p < 1e-6:
        return x
    tgt = 10 ** (rng.uniform(lo, hi) / 20)
    return x / p * tgt


def noise_floor(x, rng):
    lvl = 10 ** (rng.uniform(-72, -58) / 20)
    return x + rng.standard_normal(len(x)).astype(np.float32) * lvl


def synth_rir(rng, sr=SR):
    """Réponse impulsionnelle de pièce simple : son direct + réflexions + queue exponentielle."""
    rt60 = rng.uniform(0.15, 0.7)
    L = int(sr * min(rt60 * 1.2, 1.0))
    t = np.arange(L) / sr
    tail = rng.standard_normal(L) * np.exp(-6.9 * t / rt60)
    # matériaux : la queue perd ses aigus
    b, a = sg.butter(1, rng.uniform(2500, 7000) / (sr / 2))
    tail = sg.lfilter(b, a, tail)
    h = tail * 10 ** (rng.uniform(-22, -10) / 20) / (np.abs(tail).max() + 1e-9)
    h[0] = 1.0
    for _ in range(rng.integers(2, 6)):
        d = int(rng.uniform(0.002, 0.03) * sr)
        if d < L:
            h[d] += rng.uniform(0.1, 0.5) * rng.choice([-1, 1])
    return h.astype(np.float32)


def reverb(x, rng):
    y = sg.fftconvolve(x, synth_rir(rng))[: len(x)]
    return y.astype(np.float32)


def mix_snr(sig, noise, snr_db):
    ps = np.mean(sig ** 2) + 1e-12
    pn = np.mean(noise ** 2) + 1e-12
    return sig + noise * np.sqrt(ps / pn / 10 ** (snr_db / 10))


def bandlimit(x, lo, hi, sr=SR):
    sos = sg.butter(4, [lo / (sr / 2), min(hi, sr / 2 - 100) / (sr / 2)], btype="band", output="sos")
    return sg.sosfilt(sos, x).astype(np.float32)


def lowpass(x, fc, sr=SR):
    sos = sg.butter(6, fc / (sr / 2), output="sos")
    return sg.sosfilt(sos, x).astype(np.float32)


def radio_tv(x, rng):
    """Effet haut-parleur radio/télé : bande passante réduite + compression douce + légère saturation."""
    y = bandlimit(x, rng.uniform(120, 350), rng.uniform(3500, 7500))
    y = y / (np.abs(y).max() + 1e-9)
    drive = rng.uniform(1.5, 4)
    y = np.tanh(drive * y) / np.tanh(drive)
    return y.astype(np.float32)


# ---------------------------------------------------------------- synthèse alarme
def synth_smoke_alarm(rng, sr=SR, dur=DUR):
    """Détecteur de fumée : buzzer piézo 2,9–3,7 kHz (UL 217 : 3100±500 Hz), motif T3 (ISO 8201 :
    0,5 s ON / 0,5 s OFF ×3 puis 1,5 s) ou bip rapide continu (ex. 0,5 s ON / 0,2 s OFF, mesuré sur un
    enregistrement réel à 3,48 kHz), et ~10 % de modèles basse fréquence 520 Hz (onde carrée, NFPA 72)."""
    total = int(sr * 6)
    t = np.arange(total) / sr
    low = rng.random() < 0.10
    f0 = 520 * rng.uniform(0.97, 1.03) if low else rng.uniform(2900, 3700)
    # légère dérive / vibrato du piézo
    f_inst = f0 * (1 + rng.uniform(0.0005, 0.004) * np.sin(2 * np.pi * rng.uniform(3, 30) * t)
                   + rng.uniform(-0.002, 0.002) * t / 6)
    ph = 2 * np.pi * np.cumsum(f_inst) / sr
    if low:
        tone = sg.square(ph) * 0.8
    else:
        tone = np.sin(ph)
        for k, g in ((2, rng.uniform(0.05, 0.3)), (3, rng.uniform(0.05, 0.35))):
            if f0 * k < sr / 2 - 200:
                tone += g * np.sin(k * ph + rng.uniform(0, 6.28))
    # gabarit temporel
    pattern = rng.choice(["T3", "fast", "T3"]) if not low else "T3"
    gate = np.zeros(total)
    if pattern == "T3":
        on, off, pause = rng.uniform(0.45, 0.55), rng.uniform(0.45, 0.55), rng.uniform(1.4, 1.6)
        seq = [(on, 1), (off, 0)] * 2 + [(on, 1), (pause, 0)]
    else:
        on, off = rng.uniform(0.15, 0.55), rng.uniform(0.1, 0.35)
        seq = [(on, 1), (off, 0)]
    pos = -rng.uniform(0, 4.0)
    while pos < 6:
        for d, v in seq:
            a, b = int(max(pos, 0) * sr), int(min(pos + d, 6) * sr)
            if b > a and v:
                gate[a:b] = 1
            pos += d
    # attaques/relâchements doux (~3–8 ms)
    k = int(sr * rng.uniform(0.003, 0.008))
    gate = np.convolve(gate, np.ones(k) / k, "same")
    y = tone * gate
    # réponse du boîtier / grille
    y = sg.lfilter(*sg.iirpeak(min(f0, sr / 2 - 300) / (sr / 2), rng.uniform(2, 8)), y) * 0.5 + y * 0.5
    s = int(rng.uniform(0, 6 - dur) * sr)
    y = y[s:s + int(dur * sr)]
    if np.abs(y).max() < 1e-3:  # fenêtre tombée dans une pause : on recommence
        return synth_smoke_alarm(rng, sr, dur)
    return y.astype(np.float32)


# ---------------------------------------------------------------- synthèse choc
def synth_thud(rng, sr=SR, dur=DUR):
    """Objet / sac lourd qui tombe : choc grave amorti (modes 40–220 Hz), claquement de contact
    large bande, vibration du sol, éventuels rebonds et bruit de contenu qui se tasse."""
    n = int(sr * dur)
    y = np.zeros(n)
    t0 = rng.uniform(0.15, 0.9)

    def impact(at, amp):
        L = int(sr * 0.6)
        t = np.arange(L) / sr
        body = np.zeros(L)
        for _ in range(rng.integers(2, 5)):
            f = rng.uniform(40, 220)
            body += rng.uniform(0.3, 1) * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / rng.uniform(0.02, 0.12))
        click = rng.standard_normal(L) * np.exp(-t / rng.uniform(0.002, 0.012))
        lo = rng.uniform(200, 900)
        click = bandlimit(click, lo, rng.uniform(lo * 3, 7000))
        floor = rng.standard_normal(L) * np.exp(-t / rng.uniform(0.03, 0.15))
        floor = lowpass(floor, rng.uniform(300, 1200))
        sig = body / (np.abs(body).max() + 1e-9) + rng.uniform(0.15, 0.7) * click / (np.abs(click).max() + 1e-9) \
            + rng.uniform(0.1, 0.5) * floor / (np.abs(floor).max() + 1e-9)
        a = int(at * sr)
        m = min(L, n - a)
        if m > 0:
            y[a:a + m] += amp * sig[:m]

    impact(t0, 1.0)
    tt = t0
    for _ in range(rng.integers(0, 3)):  # rebonds
        tt += rng.uniform(0.08, 0.3)
        impact(tt, rng.uniform(0.1, 0.4))
    if rng.random() < 0.5:  # contenu du sac / objet qui glisse
        a = int((t0 + 0.02) * sr)
        L = int(sr * rng.uniform(0.2, 0.6))
        m = min(L, n - a)
        if m > 0:
            r = rng.standard_normal(m) * np.exp(-np.arange(m) / (m / 3))
            y[a:a + m] += rng.uniform(0.03, 0.12) * bandlimit(r, 500, 6000)
    return y.astype(np.float32)
