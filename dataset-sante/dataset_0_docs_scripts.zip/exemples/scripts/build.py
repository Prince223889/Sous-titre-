"""Construit le jeu de données de la station : 9 dossiers de WAV 16 kHz mono 16 bits, 2,0 s chacun.
Usage : python3 build.py <dossier_sources> <dossier_sortie>"""
import sys, os, glob, csv, json, hashlib, zlib, random
from multiprocessing import Pool
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from audiolib import *

SRC, OUT = (sys.argv[1], sys.argv[2]) if __name__ == "__main__" else ("", "")
STAGE = OUT + "_stage"
CAP = 1000

LIC = {
    "esc50": "CC BY-NC 3.0 (ESC-50, K. Piczak)",
    "coughvid": "CC BY 4.0 (COUGHVID / EPFL, via Virufy)",
    "donateacry": "ODbL 1.0 / DbCL 1.0 (Donate-a-cry corpus)",
    "snoresense": "Dépôt GPL-3.0 (Trinity1804/Snoresense, clips du jeu 'Snoring' de T. H. Khan)",
    "screams": "Non précisée (rexj8/Scream_detector_dataset, extraits NIGENS/Freesound) — usage recherche",
    "msnsd_speech": "ODbL 1.0 / Edinburgh DataShare (MS-SNSD clean speech)",
    "msnsd_noise": "CC0 (Freesound) / CC BY-SA 3.0 (DEMAND) via MS-SNSD",
    "sprsound": "CC BY 4.0 (SPRSound, Shanghai Children's Medical Center)",
    "falls": "Non précisée (charanya78/fall_detection_audios, audio de vidéos SisFall) — usage recherche",
    "alarm_real": "Non précisée (benjaminchodroff/alarmbeepdetect) — usage recherche",
    "synth": "Généré par script (libre)",
}

BG_OK = ["AirConditioner", "CopyMachine", "VacuumCleaner", "WasherDryer", "Washing", "Car", "Traffic",
         "Field", "Park", "Hallway", "Kitchen", "Office", "Typing"]
BRUIT_ESC = ["rain", "door_wood_knock", "door_wood_creaks", "engine", "footsteps", "washing_machine",
             "vacuum_cleaner", "pouring_water", "water_drops", "can_opening", "keyboard_typing", "clock_tick",
             "toilet_flush", "brushing_teeth", "hen", "rooster", "dog", "cat", "chirping_birds", "wind",
             "crackling_fire", "car_horn", "mouse_click", "drinking_sipping", "crow", "sheep", "cow", "insects",
             "crickets", "airplane", "helicopter", "frog", "pig", "chainsaw", "hand_saw", "train"]
BRUIT_SNSD = ["ShuttingDoor", "SqueakyChair", "Typing", "Munching", "CopyMachine", "AirConditioner",
              "VacuumCleaner", "WasherDryer", "Washing", "Kitchen", "LivingRoom", "Car", "Traffic", "Hallway"]
PAROLE_SNSD = ["AirportAnnouncement", "Babble", "NeighborSpeaking"]

_bg = None


def bg_pool():
    global _bg
    if _bg is None:
        _bg = []
        for f in sorted(glob.glob(f"{SRC}/snsd/noise_*/*.wav")):
            if any(os.path.basename(f).startswith(k) for k in BG_OK):
                x = load(f)
                if x is not None and len(x) > N:
                    _bg.append(x)
        esc = esc_meta()
        for r in esc:
            if r["category"] in ("rain", "wind", "crickets", "insects"):
                x = load(f"{SRC}/ESC-50/audio/{r['filename']}")
                if x is not None:
                    _bg.append(x)
    return _bg


def esc_meta():
    return list(csv.DictReader(open(f"{SRC}/ESC-50/meta/esc50.csv")))


def finish(x, rng, synthetic=False, already_narrow=False, p_bg=None):
    """Chaîne de réalisme appliquée à TOUTES les classes (mêmes probabilités pour éviter les raccourcis)."""
    x = x.astype(np.float32)
    if rng.random() < (0.6 if synthetic else 0.35):
        x = reverb(x, rng)
    if not already_narrow and rng.random() < 0.3:
        x = lowpass(x, rng.uniform(3600, 4000))  # simule micros/CAN bas de gamme et sources 8 kHz
    p = p_bg if p_bg is not None else (0.85 if synthetic else 0.5)
    if rng.random() < p:
        pool = bg_pool()
        b = pool[rng.integers(len(pool))]
        s = rng.integers(0, len(b) - N)
        x = mix_snr(x, b[s:s + N], rng.uniform(3, 25) if not synthetic else rng.uniform(0, 20))
    x = normalize(x, rng)
    x = noise_floor(x, rng)
    return x


def seed_of(*k):
    return zlib.crc32("|".join(map(str, k)).encode())


# ------------------------------------------------------------------ tâches (1 fichier source = 1 tâche)
def task_generic(args):
    cls, path, source, group, max_win, n_var, extra = args
    rng = np.random.default_rng(seed_of(cls, path))
    x = load(path)
    out = []
    if x is None:
        return out
    narrow = extra.get("narrow", False)
    segs = event_windows(x, rng, max_win=max_win, min_rel_db=extra.get("rel", -25))
    for k, s in enumerate(segs):
        for v in range(n_var):
            y = s.copy()
            if v > 0:  # variante : décalage temporel + gain + effets différents
                y = np.roll(y, int(rng.integers(-SR // 3, SR // 3)))
            if extra.get("radio_p", 0) and rng.random() < extra["radio_p"]:
                y = radio_tv(y, rng)
            y = finish(y, rng, already_narrow=narrow)
            out.append(dict(cls=cls, x=y, source=source, orig=os.path.relpath(path, SRC), group=group,
                            seg=k, var=v, synth=0, sub=extra.get("sub", "")))
    return out


def task_wheeze(args):
    path, jpath, patient = args
    rng = np.random.default_rng(seed_of("wh", path))
    x = load(path)
    if x is None:
        return []
    j = json.load(open(jpath))
    out = []
    for k, e in enumerate(j.get("event_annotation", [])):
        if e["type"] != "Wheeze":
            continue
        a, b = int(e["start"]) * SR // 1000, int(e["end"]) * SR // 1000
        c = (a + b) // 2 + int(rng.integers(-SR // 4, SR // 4))
        s = int(np.clip(c - N // 2, 0, max(0, len(x) - N)))
        seg = fit(x[s:s + N], rng)
        y = finish(seg, rng, already_narrow=True, p_bg=0.5)
        out.append(dict(cls="sifflement", x=y, source="sprsound", orig=os.path.relpath(path, SRC), group=f"spr_{patient}",
                        seg=k, var=0, synth=0, sub=j.get("record_annotation", "")))
    return out


def task_synth(args):
    cls, i = args
    rng = np.random.default_rng(seed_of("synth", cls, i))
    y = synth_smoke_alarm(rng) if cls == "alarme" else synth_thud(rng)
    y = finish(y, rng, synthetic=True)
    return [dict(cls=cls, x=y, source="synth", orig="", group=f"synth_{cls}_{i}", seg=0, var=0, synth=1, sub="")]


def run(task):
    fn, args = task
    try:
        res = fn(args)
    except Exception as ex:  # un fichier corrompu ne doit pas bloquer le reste
        print("ERREUR", args[:2] if isinstance(args, tuple) else args, ex, flush=True)
        return []
    rows = []
    for r in res:
        h = hashlib.md5(r["x"].tobytes()).hexdigest()[:10]
        fn_ = f"{STAGE}/{r['cls']}/{r['source']}_{h}.wav"
        save(fn_, r.pop("x"))
        r["tmp"] = fn_
        rows.append(r)
    return rows


def main():
    rng = random.Random(42)
    tasks = []
    esc = esc_meta()

    def esc_files(cat):
        return [r for r in esc if r["category"] == cat]

    # toux
    cv = {r["cough_path"]: r for r in csv.DictReader(open(f"{SRC}/cough/virufy-cdf-coughvid.csv"))}
    for p in sorted(glob.glob(f"{SRC}/cough/virufy-cdf-coughvid/*")):
        r = cv.get("virufy-cdf-coughvid/" + os.path.basename(p), {})
        tasks.append((task_generic, ("toux", p, "coughvid", "cv_" + r.get("patient_id", p), 1, 1,
                                     {"sub": f"age={r.get('age','')}"})))
    for r in esc_files("coughing"):
        tasks.append((task_generic, ("toux", f"{SRC}/ESC-50/audio/{r['filename']}", "esc50", f"esc_{r['src_file']}", 2, 1, {})))
    # pleurs
    for p in sorted(glob.glob(f"{SRC}/cry/donateacry_corpus_cleaned_and_updated_data/*/*")):
        tasks.append((task_generic, ("pleurs", p, "donateacry", "dac_" + os.path.basename(p)[:36], 2, 1,
                                     {"narrow": True, "sub": p.split("/")[-2]})))
    for r in esc_files("crying_baby"):
        tasks.append((task_generic, ("pleurs", f"{SRC}/ESC-50/audio/{r['filename']}", "esc50", f"esc_{r['src_file']}", 2, 2, {})))
    # ronflement
    for p in sorted(glob.glob(f"{SRC}/snore/dataset/1/*.wav")):
        tasks.append((task_generic, ("ronflement", p, "snoresense", "snr_" + os.path.basename(p), 1, 1, {"rel": -30})))
    for r in esc_files("snoring"):
        tasks.append((task_generic, ("ronflement", f"{SRC}/ESC-50/audio/{r['filename']}", "esc50", f"esc_{r['src_file']}", 3, 2, {})))
    # cri
    for p in sorted(glob.glob(f"{SRC}/screams/Project_dataset/*.wav")):
        if "long_test" in p:
            continue
        tasks.append((task_generic, ("cri", p, "screams", "scr_" + os.path.basename(p), 3, 3, {})))
    # parole
    for p in sorted(glob.glob(f"{SRC}/snsd/clean_train/*.wav")):
        tasks.append((task_generic, ("parole", p, "msnsd_speech", "sp_" + os.path.basename(p), 1, 1, {"radio_p": 0.35})))
    for p in sorted(glob.glob(f"{SRC}/snsd/noise_*/*.wav")):
        b = os.path.basename(p)
        if any(b.startswith(k) for k in PAROLE_SNSD):
            tasks.append((task_generic, ("parole", p, "msnsd_noise", "spn_" + b, 8, 1, {"radio_p": 0.2, "sub": b.split("_")[0]})))
        elif any(b.startswith(k) for k in BRUIT_SNSD):
            tasks.append((task_generic, ("bruit", p, "msnsd_noise", "bn_" + b, 4, 1, {"sub": b.split("_")[0]})))
    # bruit
    for cat in BRUIT_ESC:
        for r in esc_files(cat):
            tasks.append((task_generic, ("bruit", f"{SRC}/ESC-50/audio/{r['filename']}", "esc50", f"esc_{r['src_file']}", 1, 1, {"sub": cat})))
    for p in sorted(glob.glob(f"{SRC}/fall/Mono_audios/Non_Falls/*.wav")):
        tasks.append((task_generic, ("bruit", p, "falls", "fall_" + os.path.basename(p), 3, 1, {"sub": "activite_quotidienne"})))
    # choc (réel)
    for p in sorted(glob.glob(f"{SRC}/fall/Mono_audios/Falls/*.wav")):
        tasks.append((task_generic, ("choc", p, "falls", "fall_" + os.path.basename(p), 1, 6, {"rel": -12, "sub": "chute_reelle"})))
    # alarme (réel)
    tasks.append((task_generic, ("alarme", f"{SRC}/alarm/alarm.wav", "alarm_real", "alarm_real", 3, 5, {"rel": -30})))
    # sifflement
    for j in sorted(glob.glob(f"{SRC}/spr/Classification/**/*.json", recursive=True)):
        d = json.load(open(j))
        if any(e["type"] == "Wheeze" for e in d.get("event_annotation", [])):
            w = j.replace("_json", "_wav").replace(".json", ".wav")
            if not os.path.exists(w):
                w = glob.glob(f"{SRC}/spr/Classification/**/{os.path.basename(j)[:-5]}.wav", recursive=True)
                if not w:
                    continue
                w = w[0]
            tasks.append((task_wheeze, (w, j, os.path.basename(j).split("_")[0])))
    # synthèse
    tasks += [(task_synth, ("alarme", i)) for i in range(900)]
    tasks += [(task_synth, ("choc", i)) for i in range(720)]

    for c in ["alarme", "bruit", "choc", "cri", "parole", "pleurs", "ronflement", "sifflement", "toux"]:
        os.makedirs(f"{STAGE}/{c}", exist_ok=True)
    print(len(tasks), "tâches", flush=True)
    rows = []
    with Pool(os.cpu_count()) as pool:
        for i, r in enumerate(pool.imap_unordered(run, tasks, chunksize=4)):
            rows += r
            if i % 1000 == 0:
                print(i, len(rows), flush=True)
    json.dump(rows, open(OUT + "_rows.json", "w"))
    print("clips bruts :", len(rows))


if __name__ == "__main__":
    main()
