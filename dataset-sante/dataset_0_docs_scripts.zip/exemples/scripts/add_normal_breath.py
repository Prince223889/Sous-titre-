"""Ajoute des respirations NORMALES (SPRSound, même stéthoscope, mêmes patients) dans `bruit`,
pour que le modèle apprenne le sifflement lui-même et non « le son du stéthoscope »."""
import sys, os, glob, json, random
from multiprocessing import Pool
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build
from audiolib import *

SRC, OUT = sys.argv[1], sys.argv[2]
build.SRC = SRC
build.STAGE = OUT + "_stage"
NB = int(sys.argv[3]) if len(sys.argv) > 3 else 300


def task(args):
    path, start, end, patient, rec = args
    rng = np.random.default_rng(build.seed_of("nb", path, start))
    x = load(path)
    if x is None:
        return []
    c = (start + end) * SR // 2000 + int(rng.integers(-SR // 4, SR // 4))
    s = int(np.clip(c - N // 2, 0, max(0, len(x) - N)))
    y = build.finish(fit(x[s:s + N], rng), rng, already_narrow=True, p_bg=0.5)
    return [dict(cls="bruit", x=y, source="sprsound", orig=os.path.relpath(path, SRC), group=f"spr_{patient}",
                 seg=start, var=0, synth=0, sub="respiration_normale_stethoscope")]


if __name__ == "__main__":
    cands = []
    for j in sorted(glob.glob(f"{SRC}/spr/Classification/**/*.json", recursive=True)):
        d = json.load(open(j))
        evs = d["event_annotation"]
        # enregistrement sans aucun bruit adventice : uniquement des événements "Normal"
        if not evs or any(e["type"] != "Normal" for e in evs):
            continue
        w = glob.glob(f"{SRC}/spr/Classification/**/{os.path.basename(j)[:-5]}.wav", recursive=True)
        if not w:
            continue
        e = random.Random(j).choice(evs)
        cands.append((w[0], int(e["start"]), int(e["end"]), os.path.basename(j).split("_")[0], d["record_annotation"]))
    rnd = random.Random(11)
    rnd.shuffle(cands)
    # au plus 3 par patient pour couvrir beaucoup d'enfants
    per, sel = {}, []
    for c in cands:
        if per.get(c[3], 0) < 3:
            per[c[3]] = per.get(c[3], 0) + 1
            sel.append(c)
        if len(sel) >= NB:
            break
    with Pool(os.cpu_count()) as p:
        rows = [r for res in p.map(build.run, [(task, a) for a in sel]) for r in res]
    allrows = json.load(open(OUT + "_rows.json"))
    allrows = [r for r in allrows if r.get("sub") != "respiration_normale_stethoscope"] + rows
    json.dump(allrows, open(OUT + "_rows.json", "w"))
    print("ajoutés :", len(rows), "patients :", len(per))
