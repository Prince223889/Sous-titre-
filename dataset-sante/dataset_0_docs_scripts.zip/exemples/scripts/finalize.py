"""Sélection équilibrée (≤ CAP par classe), copie dans la structure finale, métadonnées CSV."""
import sys, os, json, csv, shutil, zlib, random, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import LIC  # noqa

OUT = sys.argv[1]
CAP = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
EX = sys.argv[3] if len(sys.argv) > 3 else "exemples"
rows = json.load(open(OUT + "_rows.json"))
rnd = random.Random(7)

by_cls = collections.defaultdict(list)
for r in rows:
    by_cls[r["cls"]].append(r)

final = []
for cls, rs in sorted(by_cls.items()):
    buckets = collections.defaultdict(list)
    for r in rs:
        buckets[(r["source"], r["sub"] if r["cls"] == "bruit" else "")].append(r)
    for b in buckets.values():
        rnd.shuffle(b)
        b.sort(key=lambda r: r["var"])  # originaux d'abord, variantes ensuite
    keys = sorted(buckets)
    picked = []
    # respirations normales au stéthoscope : contre-exemples indispensables du sifflement, gardées en entier
    for k in keys:
        if k[1] == "respiration_normale_stethoscope":
            picked += buckets[k]
            buckets[k] = []
    while len(picked) < CAP and any(buckets[k] for k in keys):
        for k in keys:
            if buckets[k] and len(picked) < CAP:
                picked.append(buckets[k].pop(0))
    final += picked

if os.path.exists(OUT):
    shutil.rmtree(OUT)
meta = []
for r in final:
    d = f"{OUT}/{r['cls']}"
    os.makedirs(d, exist_ok=True)
    name = os.path.basename(r["tmp"])
    if r["var"] > 0:
        name = name.replace(".wav", f"_var{r['var']}.wav")
    name = f"{r['cls']}_{name}"
    shutil.copy(r["tmp"], f"{d}/{name}")
    split = "test" if zlib.crc32(r["group"].encode()) % 5 == 0 else "train"
    meta.append(dict(fichier=f"{r['cls']}/{name}", classe=r["cls"], source=r["source"], sous_type=r["sub"],
                     fichier_origine=r["orig"], groupe=r["group"], synthetique="oui" if r["synth"] else "non",
                     variante=r["var"], split_conseille=split, licence=LIC[r["source"]]))
for cls in os.listdir(EX):
    if os.path.isdir(f"{EX}/{cls}"):
        os.makedirs(f"{OUT}/{cls}", exist_ok=True)
        shutil.copy(f"{EX}/{cls}/LISEZ-MOI.txt", f"{OUT}/{cls}/LISEZ-MOI.txt")
meta.sort(key=lambda m: m["fichier"])
with open(f"{OUT}/metadata.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(meta[0]))
    w.writeheader()
    w.writerows(meta)
c = collections.Counter((m["classe"], m["source"], m["synthetique"]) for m in meta)
for k in sorted(c):
    print(k, c[k])
print(collections.Counter(m["classe"] for m in meta))
